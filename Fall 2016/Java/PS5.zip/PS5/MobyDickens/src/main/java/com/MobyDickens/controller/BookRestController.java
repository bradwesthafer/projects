package com.MobyDickens.controller;

import com.MobyDickens.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Brad on 11/20/2016.
 */
//@RestController
public class BookRestController {
/*    @Autowired
    protected BookService bookService;*/
}
