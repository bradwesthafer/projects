package com.MobyDickens.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Created by Brad on 11/20/2016.
 */
//@Controller
public class SiteController {
    /*@RequestMapping(name="/search", method = RequestMethod.GET)
    public String search() {
        return "search";
    }

    @RequestMapping(name="/contact-us", method = RequestMethod.GET)
    public String contact() {
        return "contact";
    }

    @RequestMapping(name="/login", method = RequestMethod.GET)
    public String login() {
        return "login";
    }*/
}
